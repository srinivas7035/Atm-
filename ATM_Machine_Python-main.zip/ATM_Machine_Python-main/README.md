# ATM Machine

A Miniproject on implementing operations of User Manual Of ATM Machine which includes Statement, Withdraw, Deposit, Change PIN and Quit By Using Python Source Code.

# Language

Python

# Features

Since it is an ATM Machine, Initially i declared some of the accounts and initialized the amount to zero, And doing following operations on that account.

1. Deposit
2. Withdrawal
3. Balance Enquiry

# Modules

1. Deposit
2. Withdrawal
3. Balance Enquiry
4. Statement
5. Quit

# FEEDBACK
Any suggestion and feedback is welcome. You can message me on Instagram
- https://www.instagram.com/itz_me_sooriii?r=nametag
